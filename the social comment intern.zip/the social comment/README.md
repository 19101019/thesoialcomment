# 🤘DASHBOARD


Dashboaed is a great template to quick-start development of SAAS, CMS, IoT Dashboard, E-Commerce apps, etc  
Lite version of a Light Blue includes following features and pages:

* Bootstrap 4+ & SCSS
* Responsive layout
* React Chart.js
* Simple login / logout 
* Error page
* Styled Bootstrap components like buttons, modals, etc


